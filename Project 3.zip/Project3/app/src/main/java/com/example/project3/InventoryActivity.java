package com.example.project3;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class InventoryActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private EditText itemNameField, quantityField;
    private Button addItemButton, viewItemsButton, updateItemButton, deleteItemButton;
    private TextView inventoryList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        dbHelper = new DatabaseHelper(this);

        // Initialize UI components
        itemNameField = findViewById(R.id.itemName);
        quantityField = findViewById(R.id.quantity);
        addItemButton = findViewById(R.id.addItem);
        viewItemsButton = findViewById(R.id.viewItems);
        updateItemButton = findViewById(R.id.updateItem);
        deleteItemButton = findViewById(R.id.deleteItem);
        inventoryList = findViewById(R.id.inventoryList);

        // Add a new inventory item
        addItemButton.setOnClickListener(v -> {
            String itemName = itemNameField.getText().toString();
            String quantityText = quantityField.getText().toString();

            if (itemName.isEmpty() || quantityText.isEmpty()) {
                Toast.makeText(this, "Please enter item name and quantity", Toast.LENGTH_SHORT).show();
                return;
            }

            int quantity = Integer.parseInt(quantityText);
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put("ITEM_NAME", itemName);
            values.put("QUANTITY", quantity);

            long result = db.insert("inventory", null, values);

            if (result != -1) {
                Toast.makeText(this, "Item Added", Toast.LENGTH_SHORT).show();
                clearFields();
            } else {
                Toast.makeText(this, "Error Adding Item", Toast.LENGTH_SHORT).show();
            }
        });

        // View all inventory items
        viewItemsButton.setOnClickListener(v -> {
            SQLiteDatabase db = dbHelper.getReadableDatabase();
            Cursor cursor = db.rawQuery("SELECT * FROM inventory", null);

            if (cursor != null && cursor.getCount() > 0) {
                StringBuilder items = new StringBuilder();

                while (cursor.moveToNext()) {
                    String itemName = cursor.getString(cursor.getColumnIndex("ITEM_NAME"));
                    int quantity = cursor.getInt(cursor.getColumnIndex("QUANTITY"));
                    items.append(itemName).append(": ").append(quantity).append("\n");
                }
                inventoryList.setText(items.toString());
                cursor.close();
            } else {
                inventoryList.setText("No items found");
            }
        });

        // Update an existing inventory item
        updateItemButton.setOnClickListener(v -> {
            String itemName = itemNameField.getText().toString();
            String quantityText = quantityField.getText().toString();

            if (itemName.isEmpty() || quantityText.isEmpty()) {
                Toast.makeText(this, "Please enter item name and quantity", Toast.LENGTH_SHORT).show();
                return;
            }

            int quantity = Integer.parseInt(quantityText);
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put("QUANTITY", quantity);

            int rowsUpdated = db.update("inventory", values, "ITEM_NAME = ?", new String[]{itemName});

            if (rowsUpdated > 0) {
                Toast.makeText(this, "Item Updated", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Item Not Found", Toast.LENGTH_SHORT).show();
            }

            clearFields();
        });

        // Delete an inventory item
        deleteItemButton.setOnClickListener(v -> {
            String itemName = itemNameField.getText().toString();

            if (itemName.isEmpty()) {
                Toast.makeText(this, "Please enter item name to delete", Toast.LENGTH_SHORT).show();
                return;
            }

            SQLiteDatabase db = dbHelper.getWritableDatabase();

            int rowsDeleted = db.delete("inventory", "ITEM_NAME = ?", new String[]{itemName});

            if (rowsDeleted > 0) {
                Toast.makeText(this, "Item Deleted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Item Not Found", Toast.LENGTH_SHORT).show();
            }

            clearFields();
        });
    }

    // Helper method to clear input fields
    private void clearFields() {
        itemNameField.setText("");
        quantityField.setText("");
    }
}